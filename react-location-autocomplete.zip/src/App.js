import LocationSearch from "./components/LocationSearch.component";


function App() {
  return (
    <div className="App">
      < LocationSearch className="w-6/12 mx-auto p-5"/>
    </div>
  );
}

export default App;
