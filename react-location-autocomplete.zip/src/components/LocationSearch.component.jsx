import React, { useState } from "react";
import { ReactSearchAutocomplete } from "react-search-autocomplete";

const LocationSearch = ({className}) => {
  //   const [searchQuery, setSearchQuery] = useState("");
  const [locations, setLocations] = useState([]);
  const [apiRes, setApiRes] = useState([]);

  const FetchApi = (string, resultse) => {
    fetch(
      `https://api.locationiq.com/v1/autocomplete.php?key=pk.7eb1ffef27f722e89d8ee135078399b4&q=${string}&limit=5`
    )
      .then((res) => res.json())
      .then((res) => {
        setApiRes(res);
        setLocations(
          !res.error &&
            res.map((location, index) => {
              return { id: index, name: location.display_name };
            })
        );
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className ={className}>
      <ReactSearchAutocomplete
        items={locations}
        onSearch={FetchApi}
        autoFocus
      />
    </div>
  );
};

export default LocationSearch;
